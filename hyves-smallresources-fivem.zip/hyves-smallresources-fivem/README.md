# hyves-smallresources
Small Resources and Better Mechanics in FiveM

hyves-smallresources contains many new features, mechanics and settings. You can add files in your qb-smallresources file.

## Info & Features

- Action Mode
- AFK Kick
- FPS mod when shooting from the car
- Back Items
- Blips
- Carry
- Crouch
- Discord Rich
- Double Jump Blocker
- Rockstar Editor
- Hands Up
- Holster
- Point
- Prop Delete (Broken power poles etc.)
- nui_devtools Blocker
- 4:3 Resolution Blocker (soon)
- Weapon Shooting Mode (3 modes)
- Tackle
- Vehicle Push
- Hat and mask falling to the ground after punching
- Automatically look at the face of the talking player

## Previews (new preview videos coming soon)

Weapon Mode: https://streamable.com/sjy0mm





Errors may occur, do not forget to report!
